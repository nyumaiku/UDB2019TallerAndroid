package sv.edu.udb.ejemplosemiv;

import android.arch.persistence.room.Room;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;

import java.util.List;

import sv.edu.udb.ejemplosemiv.data.AppDatabase;
import sv.edu.udb.ejemplosemiv.data.IPersonaDAO;
import sv.edu.udb.ejemplosemiv.data.Persona;

public class AddPersonaActivity extends AppCompatActivity implements Validator.ValidationListener {


    @NotEmpty(message = "El nombre no puede estar vacio")
    EditText nombre;

    @NotEmpty(message = "Ingrese una edad")
    EditText edad;

    Validator validator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_persona);

        nombre = findViewById(R.id.nombre);
        edad = findViewById(R.id.edad);


        validator = new Validator(this);
        validator.setValidationListener(this);
    }

    public void addPersona(View view) {


        validator.validate();

    }


    public void addNew(){
        AppDatabase database = Room.databaseBuilder(this, AppDatabase.class, "mydb")
                .allowMainThreadQueries()
                .build();


        IPersonaDAO dao = database.getIPersonaDAO();

        Persona persona = new Persona();

        persona.setNombre( nombre.getText().toString());

        persona.setEdad( edad.getText().toString() );

        dao.insert(persona);

    }

    @Override
    public void onValidationSucceeded() {

        addNew();

        finish();
    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        for (ValidationError error : errors) {
            View view = error.getView();
            String message = error.getCollatedErrorMessage(this);

            // Display error messages ;)
            if (view instanceof EditText) {
                ((EditText) view).setError(message);
            } else {
                Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            }
        }
    }
}
