package sv.edu.udb.ejemplosemiv;

import android.arch.persistence.room.Room;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.View;
import android.widget.Toast;

import java.util.List;

import sv.edu.udb.ejemplosemiv.data.AppDatabase;
import sv.edu.udb.ejemplosemiv.data.IPersonaDAO;
import sv.edu.udb.ejemplosemiv.data.Persona;
import sv.edu.udb.ejemplosemiv.data.PersonaDAO;
import sv.edu.udb.ejemplosemiv.util.PersonaAdapter;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;

    AppDatabase database;

    IPersonaDAO dao;

    List<Persona> personaList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerview);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        database = Room.databaseBuilder(this, AppDatabase.class, "mydb")
                .allowMainThreadQueries()
                .build();

        dao = database.getIPersonaDAO();

    }

    @Override
    protected void onResume() {
        super.onResume();
        update();
    }

    private void update(){

        personaList =  dao.getPersonasList();

        final PersonaAdapter adapter = new PersonaAdapter(personaList,this);

        recyclerView.setAdapter(adapter);


        ItemTouchHelper.SimpleCallback simpleItemTouchCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT ) {

            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                Toast.makeText(MainActivity.this, "on Move", Toast.LENGTH_SHORT).show();
                return false;
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int swipeDir) {
                Toast.makeText(MainActivity.this, "Eliminado", Toast.LENGTH_SHORT).show();
                //Remove swiped item from list and notify the RecyclerView
                int position = viewHolder.getAdapterPosition();

                Persona tmp = personaList.get(position);

                dao.delete(tmp);

                personaList.remove(position);

                adapter.notifyDataSetChanged();

            }
        };

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleItemTouchCallback);
        itemTouchHelper.attachToRecyclerView(recyclerView);
    }

    public void add(View view) {

        Intent intent = new Intent(this, AddPersonaActivity.class);

        startActivity(intent);
    }
}
