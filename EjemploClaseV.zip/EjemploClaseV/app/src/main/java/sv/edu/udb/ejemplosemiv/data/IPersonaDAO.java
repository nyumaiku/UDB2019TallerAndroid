package sv.edu.udb.ejemplosemiv.data;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import java.util.List;

@Dao
public interface IPersonaDAO {


    @Insert
    public void insert(Persona persona);

    @Update
    public void update(Persona persona);

    @Delete
    public void delete(Persona persona);

    @Query("SELECT * FROM Personas")
    public List<Persona> getPersonasList();

    @Query("SELECT * FROM Personas where id = :id")
    public Persona getPersonaById(long id);

}
