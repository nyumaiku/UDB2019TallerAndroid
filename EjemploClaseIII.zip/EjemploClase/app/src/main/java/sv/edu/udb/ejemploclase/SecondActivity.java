package sv.edu.udb.ejemploclase;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SecondActivity extends AppCompatActivity {

    EditText numero;

    TextView resultado;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        this.numero = findViewById(R.id.numero);

        this.resultado = findViewById(R.id.resultado);

    }


    public void calcular(View view) {
        double valorNumero = Double.parseDouble(numero.getText().toString());
        double resultado=1;

        Log.d("UDBTest","" + valorNumero);

        for(int i=1; i<=valorNumero;i++){
            resultado *= i;
        }

        Log.d("UDBTest","" + resultado);

        this.resultado.setText(resultado + "");


    }

    public void test(View view){

        Toast.makeText(this,"HOLA MUNDO",Toast.LENGTH_LONG).show();

        Log.d("UDBTest","Has impreso tu primer depuracion");

    }
}
