package sv.edu.udb.ejemplosemiv.util;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import sv.edu.udb.ejemplosemiv.R;
import sv.edu.udb.ejemplosemiv.data.Persona;

public class PersonaAdapter extends RecyclerView.Adapter<PersonaAdapter.ViewHolder> {


    Context context;
    List<Persona> personaList;

    public PersonaAdapter(List<Persona> personas, Context context){
        this.context = context;
        this.personaList = personas;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater =  LayoutInflater.from(context);

        View view = inflater.inflate(R.layout.item,viewGroup,false);

        ViewHolder viewHolder =  new ViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        Persona tmp = this.personaList.get(i);

        viewHolder.nombre.setText(tmp.getNombre());
        viewHolder.edad.setText(tmp.getEdad());

    }

    @Override
    public int getItemCount() {
        return this.personaList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView nombre;
        TextView edad;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nombre = itemView.findViewById(R.id.tvnombre);
            edad = itemView.findViewById(R.id.tvedad);
        }
    }
}
