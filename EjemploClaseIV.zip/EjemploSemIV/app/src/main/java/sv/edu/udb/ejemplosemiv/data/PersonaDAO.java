package sv.edu.udb.ejemplosemiv.data;

import java.util.ArrayList;
import java.util.List;

public class PersonaDAO {

    public List<Persona> getPersonas(){
        List<Persona> lista = new ArrayList<>();

        Persona a = new Persona();

        a.setNombre("Miguel");
        a.setEdad("33");
        lista.add(a);

        a = new Persona();


        a.setNombre("Jose");
        a.setEdad("45");
        lista.add(a);

        a = new Persona();

        a.setNombre("Messi");
        a.setEdad("32");
        lista.add(a);


        a.setNombre("Miguel");
        a.setEdad("33");
        lista.add(a);

        a = new Persona();


        a.setNombre("Jose");
        a.setEdad("45");
        lista.add(a);

        a = new Persona();

        a.setNombre("Messi");
        a.setEdad("32");
        lista.add(a);



        a.setNombre("Miguel");
        a.setEdad("33");
        lista.add(a);

        a = new Persona();


        a.setNombre("Jose");
        a.setEdad("45");
        lista.add(a);

        a = new Persona();

        a.setNombre("Messi");
        a.setEdad("32");
        lista.add(a);



        a.setNombre("Miguel");
        a.setEdad("33");
        lista.add(a);

        a = new Persona();


        a.setNombre("Jose");
        a.setEdad("45");
        lista.add(a);

        a = new Persona();

        a.setNombre("Messi");
        a.setEdad("32");
        lista.add(a);




        a.setNombre("Miguel");
        a.setEdad("33");
        lista.add(a);

        a = new Persona();


        a.setNombre("Jose");
        a.setEdad("45");
        lista.add(a);

        a = new Persona();

        a.setNombre("Messi");
        a.setEdad("32");
        lista.add(a);

        return lista;
    }

}
